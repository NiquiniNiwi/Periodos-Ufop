#include <assert.h>
#include "model.h"

int main (){ return 0; }