var searchData=
[
  ['logistic_24',['Logistic',['../class_logistic.html',1,'']]]
];
