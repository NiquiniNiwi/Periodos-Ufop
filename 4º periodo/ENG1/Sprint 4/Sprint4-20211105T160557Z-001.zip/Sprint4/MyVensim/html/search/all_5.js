var searchData=
[
  ['logistic_8',['Logistic',['../class_logistic.html',1,'Logistic'],['../class_logistic.html#ae137bd4c8e3d59f2860b89b4e8a5f43c',1,'Logistic::Logistic()']]]
];
