var searchData=
[
  ['logistic_34',['Logistic',['../class_logistic.html#ae137bd4c8e3d59f2860b89b4e8a5f43c',1,'Logistic']]]
];
