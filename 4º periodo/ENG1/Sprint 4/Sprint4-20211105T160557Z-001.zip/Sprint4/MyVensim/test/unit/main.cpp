#include "unit_tests.h"

int main (){

    testFlow();
    testModel();
    testSystem();

    return 0;
}