function nimg = Q2(img, mask)
  [lin, col, ~] = size(img);
  nimg = ind2rgb(gray2ind(img), gray);
  rgb = gray2ind(mask);
  [R, G, B] = ind2rgb(rgb, gray);
  R = R;
  G = G;
  B = B*2;
  rgb = [R, G, B];
  for i = 1 : lin
    for j = 1 : col
      if mask(i,j) == 0
        nimg(i,j) = rgb(i,j);
      endif
    endfor
  endfor
