function Q1(i)
  id = im2double(i);
  [lin, col, ~] = size(i);
  im = zeros(lin, col);
  for i = 1 : lin
    for j = 1 : col
      im(i,j) = id(i,j);
    endfor
  endfor
  
  SobelResult = edge(im, "Sobel");
  
  PrewittResult = edge(im, "Prewitt");
  
  RobertsResult = edge(im, "Roberts");
  
  CannyResult = edge(im, "Canny");
  
  LaplacianoResult = edge(im, "LoG");
  
  ZCResult = edge(im, "zerocross", 0.5, 0.1);
  
##  figure(1)
##  imshow(SobelResult);
##  figure(2)
##  imshow(PrewittResult);
##  figure(3)
##  imshow(RobertsResult);
##  figure(4)
##  imshow(CannyResult);
##  figure(5)
##  imshow(LaplacianoResult);
##  figure(6)
##  imshow(ZCResult);

  disp("Melhor resultado obitido foi em Canny");
  imshow(CannyResult);