#ifndef UNIT_TESTS_H
#define UNIT_TESTS_H
#include "../../src/model.h"

#include <assert.h>
#include <math.h>

void testFlow();
void testModel();
void testSystem();

#endif