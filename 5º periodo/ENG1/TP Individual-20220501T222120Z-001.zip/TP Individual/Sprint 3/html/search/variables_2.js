var searchData=
[
  ['name_81',['name',['../class_system.html#a29fe2868c0d56fdebc67f1bef5d5cca3',1,'System']]]
];
