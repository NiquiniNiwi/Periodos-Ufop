#include "addvendedor.h"
#include "ui_addvendedor.h"

addVendedor::addVendedor(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addVendedor)
{
    ui->setupUi(this);
}

addVendedor::~addVendedor()
{
    delete ui;
}

void addVendedor::on_pushButtonAdd_clicked()
{
        QString nome = ui->lineEditNome->text();
        QString cpf = ui->lineEditCPF->text();
        QString salario = ui->lineEditSalario->text();
        QString dtNasc = ui->lineEditDataNasc->text();
        QString sexo = ui->lineEditSexo->text();
        QString endereco = ui->lineEditEndereco->text();

        funcionarios novo (nome.toStdString(), cpf.toStdString(), dtNasc.toStdString(), salario.toInt(), sexo.toStdString(), endereco.toStdString());

        funcionarios :: addNovoVendedor(novo);
}


void addVendedor::on_pushButtonBack_clicked()
{
    close();
}

