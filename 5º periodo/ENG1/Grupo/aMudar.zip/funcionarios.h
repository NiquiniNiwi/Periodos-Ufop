#ifndef FUNCIONARIOS_H
#define FUNCIONARIOS_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class funcionarios
{
public:
    funcionarios();
    funcionarios(string nome, string cpf, string dn, int salario, string sexo, string end);
    ~funcionarios();

    static vector <funcionarios> criarFuncionariosTeste ();
    static void criarFuncionariosParaTeste();
    static void addNovoVendedor (funcionarios novo);
    static void printVendedores ();

private:
    string nome;
    string cpf;
    string dataNascimento;
    int salario;
    string sexo;
    string endereco;

    static vector <funcionarios> vVendedores;
};

#endif // FUNCIONARIOS_H
