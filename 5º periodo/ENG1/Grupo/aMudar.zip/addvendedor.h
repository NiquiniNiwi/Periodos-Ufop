#ifndef ADDVENDEDOR_H
#define ADDVENDEDOR_H

#include <QDialog>

#include "funcionarios.h"

namespace Ui {
class addVendedor;
}

class addVendedor : public QDialog
{
    Q_OBJECT

public:
    explicit addVendedor(QWidget *parent = nullptr);
    ~addVendedor();

private slots:
    void on_pushButtonAdd_clicked();

    void on_pushButtonBack_clicked();

private:
    Ui::addVendedor *ui;
};

#endif // ADDVENDEDOR_H
