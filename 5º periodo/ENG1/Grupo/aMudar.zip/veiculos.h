#ifndef VEICULOS_H
#define VEICULOS_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class veiculos
{

private:
    string veiculo;
    string proprietario;
    int valor;
    string placa;
    string renavam;

    static vector <veiculos> vVeiculos;


public:
    veiculos (string veiculo, string prop, int valor, string placa, string renavam);
    veiculos();
    ~veiculos();
    static void addVeiculos (veiculos novo);

    void saida (ostream &) const;
    friend ostream& operator<<(ostream &, const veiculos &);

};

#endif // VEICULOS_H
