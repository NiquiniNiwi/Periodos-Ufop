#include "vendas.h"
#include "ui_vendas.h"

vendas::vendas(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::vendas)
{
    ui->setupUi(this);
}

vendas::~vendas()
{
    delete ui;
}

void vendas::on_pushButtonBack_clicked()
{
    close();
    this->parentWidget()->show();
}


void vendas::on_pushButtonSold_clicked()
{
    QString carro = ui->lineEditCar->text();
    QString proprietario = ui->lineEditOwner->text();
    QString valor = ui->lineEditValue->text();
    QString placa = ui->lineEditPlate->text();
    QString renavam = ui->lineEditRENAVAM->text();

    ui->lineEditCar->clear();
    ui->lineEditOwner->clear();
    ui->lineEditValue->clear();
    ui->lineEditPlate->clear();
    ui->lineEditRENAVAM->clear();

    veiculos novo (carro.toStdString(), proprietario.toStdString(), valor.toInt(), placa.toStdString(), renavam.toStdString());

    veiculosVendidos.push_back(novo);
    veiculos :: addVeiculos(novo);

    for (auto i : veiculosVendidos){
        cout << i;
    }

}

