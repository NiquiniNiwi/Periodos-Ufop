#ifndef UNIT_TESTS_H
#define UNIT_TESTS_H
#include "../../src/lib/model.h"

#include <assert.h>
#include <math.h>

#endif