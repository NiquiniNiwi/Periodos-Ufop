var searchData=
[
  ['logistic_25',['Logistic',['../class_logistic.html',1,'Logistic'],['../class_logistic.html#ae137bd4c8e3d59f2860b89b4e8a5f43c',1,'Logistic::Logistic()'],['../class_logistic.html#a66b0c8cb54157aaf95263122380039e9',1,'Logistic::Logistic(System *source, System *destination)']]],
  ['logisticalfuncionaltest_26',['logisticalFuncionalTest',['../functional__tests_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;functional_tests.cpp'],['../functional__tests_8h.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;functional_tests.cpp']]]
];
