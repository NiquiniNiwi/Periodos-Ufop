var searchData=
[
  ['add_0',['add',['../class_model.html#a70362afdd9db6268b4adaedfeddb2935',1,'Model::add(System *)=0'],['../class_model.html#ac1e19f5fcc4ced9defbfe2847a26ff33',1,'Model::add(Flow *)=0'],['../class_model___imp.html#ad417a5c0c859750c3f301c0c8d634d6f',1,'Model_Imp::add(System *)'],['../class_model___imp.html#aaf507dc3be98f443c96118aae4138251',1,'Model_Imp::add(Flow *)']]]
];
