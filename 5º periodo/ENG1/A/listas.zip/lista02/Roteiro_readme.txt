1) Instalar QT
2) Apresentação "Pq QT?" (slides de BCC322)
2) Abrir command MinGW a partir do grupo QT no menu principal do Windows
3) Criar diretorio novo para a aula pratica no raiz (c:\Aula01\listaC e c:\Aula01\listaC++)
4) Copiar todos os arquivos das listas o respectivos diretorios
5) Mudar para um dos diretorios criados
6) Compilar "main.cpp" com a linha de comando "g++  main.cpp" e executar "a.exe" explicando o output
7) Repetir passo 6 para cada "main.cpp" contido no diretorio das listas