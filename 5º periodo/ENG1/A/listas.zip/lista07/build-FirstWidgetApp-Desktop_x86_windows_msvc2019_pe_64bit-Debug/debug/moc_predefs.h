#define _MSC_EXTENSIONS 
#define _MSC_VER 1928
#define _MSC_FULL_VER 192829915
#define _MSC_BUILD 0
#define _M_AMD64 100
#define _M_X64 100
#define _WIN64 
#define _WIN32 
#define _CPPRTTI 
#define _DEBUG 
#define _MT 
#define _DLL 
#define _UTF8 
