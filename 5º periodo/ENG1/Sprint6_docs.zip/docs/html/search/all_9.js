var searchData=
[
  ['logistic_0',['Logistic',['../class_logistic.html',1,'Logistic'],['../class_logistic.html#ae137bd4c8e3d59f2860b89b4e8a5f43c',1,'Logistic::Logistic()'],['../class_logistic.html#ae137bd4c8e3d59f2860b89b4e8a5f43c',1,'Logistic::Logistic()']]],
  ['logistic_1',['LOGISTIC',['../functional__tests_8h.html#a4dd5812520f0d909b360c24636086bee',1,'LOGISTIC():&#160;functional_tests.h'],['../unit__model_8h.html#a4dd5812520f0d909b360c24636086bee',1,'LOGISTIC():&#160;unit_model.h']]],
  ['logisticalfuncionaltest_2',['logisticalFuncionalTest',['../functional__tests_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;functional_tests.cpp'],['../functional__tests_8h.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;functional_tests.cpp']]]
];
