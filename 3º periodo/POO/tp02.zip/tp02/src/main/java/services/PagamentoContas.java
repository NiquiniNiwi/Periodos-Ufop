/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package services;

import java.util.ArrayList;
import tools.Conta;

public class PagamentoContas {
    private final ArrayList<Conta> contasClinica;

    public PagamentoContas() {
        contasClinica = new ArrayList<>();
    }
    
    public void addConta(Conta c) {
        contasClinica.add(c);
    }
    
    public ArrayList<Conta> getContasClinica() {
        return contasClinica;
    }
}
