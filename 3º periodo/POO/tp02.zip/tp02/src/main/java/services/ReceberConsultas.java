/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.ArrayList;
import tools.PagamentoConsulta;

/**
 *
 * @author Niquini
 */
public class ReceberConsultas {
    private ArrayList<PagamentoConsulta> consultas;
    
    public void Consulta() {
        consultas = new ArrayList<>();
    }
    
    public void addConsulta(PagamentoConsulta c) {
        consultas.add(c);
    }
    
    public ArrayList<PagamentoConsulta> getConsultas() {
        return consultas;
    }
}
