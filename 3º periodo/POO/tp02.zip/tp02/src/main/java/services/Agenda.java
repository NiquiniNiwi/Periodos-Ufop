/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.SortedSet;
import java.util.TreeSet;
import tools.Consulta;

public class Agenda {
    private SortedSet<Consulta> agenda;
    
    public void Agenda() {
        agenda = new TreeSet<>();
    }
    
    public void addToAgenda(Consulta c) {
        agenda.add(c);
    }
    
    public void removeFromAgenda(Consulta c) {
        agenda.remove(c);
    }
    
    public void editNomeAgenda(Consulta c, String novoNome) {
        // Se o novo nome for igual ao antigo, nenhuma atualização é necessária
        if(c.getNome().equals(novoNome)) return;
        // Se for diferente, atualizo o nome
        c.setNome(novoNome);
        if(!agenda.contains(c)) {
            agenda.add(c);
        }
    }
    
    public void editDataAgenda(Consulta c, String novaData) {
        // Se a nova data for igual a antiga, nenhuma atualização é necessária
        if(c.getData().equals(novaData)) return;
        // Se for diferente, atualizo a data
        c.setNome(novaData);
        if(!agenda.contains(c)) {
            agenda.add(c);
        }
    }
    
    public SortedSet<Consulta> getAgenda(){
        return agenda;
    }
}
