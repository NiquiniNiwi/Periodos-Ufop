/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import tools.DiaTrabalho;

public class FolhaDePonto {
    private SortedSet<DiaTrabalho> fp;

    public void FolhaDePonto() {
        fp = new TreeSet<>();
    }
    
    public void adicionarFolhaDePonto(DiaTrabalho d) {
        fp.add(d);
    }

    public SortedSet<DiaTrabalho> mostrarFolha(String nome) {
        return fp;
    }
}

