/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import services.Agenda;

public class Dentista extends Funcionario {
    private int pacientes;
    private Agenda agenda;

    public Dentista(String nome, int salario, int pacientes) {
        // Chama construtor da classe Base Funcionario
        super(nome, salario);
        this.pacientes = pacientes < 0 ? 0 : pacientes;
        agenda.Agenda();
    }

    public int getpacientes() {
        return pacientes;
    }

    public void setPacientes(int p) {
        // Se valor fornecido for negativo, pacientes toma valor 0
        pacientes = p < 0 ? 0 : p;
    }
}
