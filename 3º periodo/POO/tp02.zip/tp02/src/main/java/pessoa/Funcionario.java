/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import services.Agenda;
import services.FolhaDePonto;

public class Funcionario extends Pessoa {
    private double salario;
    private Agenda agenda;
    private FolhaDePonto folhaDePonto;
    
    public Funcionario() {
        super();
        this.salario = 0;
        this.agenda = new Agenda();
        this.folhaDePonto = new FolhaDePonto();
    }

    public Funcionario(double salario) {
        super();
        this.salario = salario;
        this.agenda = new Agenda();
        this.folhaDePonto = new FolhaDePonto();
    }

    public Funcionario(String nome, double salario) {
        super(nome);
        this.salario = salario;
        this.agenda = new Agenda();
        this.folhaDePonto = new FolhaDePonto();
    }

    public double getsalario() {
        return salario;
    }

    public void setSalario(double s) {
        // Se valor fornecido for negativo, salario toma valor 0
        salario = s < 0 ? 0 : s;
    }

    public void printFolhaDePonto() {
        System.out.println("Printando");
        folhaDePonto.mostrarFolha(super.getNome());
    }
}
