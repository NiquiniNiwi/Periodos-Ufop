/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package driver;
import GUI.Login;
import java.util.Vector;
//Import all
import pessoa.*;

import services.*;

import tools.*;

import users.*;

public class Main {
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print(("Sistema funcionando."));
        Vector<UserGeral> UsuariosGerais = new Vector<UserGeral>();
        Vector<AssistenteAdm> UsuariosAssist = new Vector<AssistenteAdm>();
        Administrador adm = new Administrador();
        Vector<Dentista> dent = new Vector<Dentista>();
        ReceberConsultas con = new ReceberConsultas();
        PagamentoContas pgc = new PagamentoContas();
        new Login(UsuariosGerais, UsuariosAssist, adm, dent, con, pgc).setVisible(true);
    }
}
