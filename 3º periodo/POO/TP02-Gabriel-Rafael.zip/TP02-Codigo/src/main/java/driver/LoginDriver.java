/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package driver;
        
public class LoginDriver {
    // Pedir login e senha do usuário
    
    // Verificar se existe login e senha corretos
}
