#include "tool.hpp"

void limpaTela(){
    system("cls");
}