#ifndef TOOL_H
#define TOOL_H

#include <iostream>

void limpaTela();

#endif